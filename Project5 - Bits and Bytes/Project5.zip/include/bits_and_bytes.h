#ifndef __BITS_AND_BYTES
#define __BITS_AND_BYTES

void extracting_fields();
void packing_bytes();
void print_bits();
void print_char();
void print_float();
void print_int();
void print_it();
void unpacking_bytes();
void updating_fields();

#endif